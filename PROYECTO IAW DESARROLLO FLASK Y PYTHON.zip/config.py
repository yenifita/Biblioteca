#Configuración del archivo config.py con las credenciales de la base de datos.

import pymysql

DB_CONFIG = {
    "host": "10.3.29.20",
    "port": 33060,
    "user": "user_gr4",
    "password": "user_gr4",
    "database": "gr4_db"
}
